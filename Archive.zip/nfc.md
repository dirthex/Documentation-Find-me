# How To Use Nfc Tags ?

### Step 1

 - you need to have or Buy NFC Tags Like this one for example : [AliExpress] or find your suplliers

### step 2 write Data on Nfc Tags
 
 - Youn can use app like [Nfc Tools on android] or [Nfc Tools on Ios]
 - Refere to our Tutorial [video] to learn how to code an url on the Tag; 

 > the url with /tag/:tag refere to your product , the /pharma/:id refere <Strong>Ids for stores can be found on HomeData and Ids for products can be found on Tags on data.js </strong>

### step 3 Link with your domaine Name

 - All link that you will use is linked to our domaine name e-paper.link
 - to change that and use tag with your domaine name go to folder static/data.js
 - and changes BASE_URL and STRING_URL

> ##### respect format of link like the one we did

> ##### For opnening the app when scaning nfc tag when the app is closed refere to section Universal Linking



 [video]:https://www.youtube.com/watch?v=8wydLcHzIJQ
 [Nfc Tools on Ios]:https://apps.apple.com/us/app/nfc-tools/id1252962749
 [Nfc Tools on android]:https://play.google.com/store/apps/details?id=com.wakdev.wdnfc&hl=en_GB
 [AliExpress]: https://fr.aliexpress.com/item/32968995666.html?spm=a2g0w.search0302.3.1.316c7a16JP74gI&ws_ab_test=searchweb0_0,searchweb201602_0,searchweb201603_0,ppcSwitch_0&algo_pvid=e88a1f2f-37e0-44b8-987d-1e5c66e01bf5&algo_expid=e88a1f2f-37e0-44b8-987d-1e5c66e01bf5-0