# How to Use Qr code ?

### Step 1

 - you need to have an QR code that contain an url for creating one use: [Generate Qr code]
 - Fill in the ENTER CONTENT url like  https://www.e-paper.link/tag/3 or https://www.e-paper.link/pharma/2 
 > the url with /tag/:tag refere to your product , the /pharma/:id refere <Strong>Ids for stores can be found on HomeData and Ids for products can be found on Tags on data.js </strong>
 - Next click on Create Qr code , then scan the tag and you can download it and use it as you want


### step 2 Link with your domaine Name

 - All link that you will use is linked to our domaine name e-paper.link
 - to change that and use tag with your domaine name go to folder static/data.js
 - and changes BASE_URL and STRING_URL

> ##### respect format of link like the one we did

> ##### For opnening the app when scaning nfc tag when the app is closed refere to section Universal Linking




 [Generate Qr code]: https://www.qrcode-monkey.com/