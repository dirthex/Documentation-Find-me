# Firebase

## Configuration Firebase

> Go to firebase  [Site] Sign up and ther click create new project

![Create Project](https://res.cloudinary.com/testcloudperfom-shop/image/upload/v1599354290/Capture_d_e%CC%81cran_2020-09-06_a%CC%80_02.04.25_mb4zyh.png)

###### Click Continue till you finish Creation of your project


### Android Config

##### Now configure FireBase for android click on 

![Create Project](https://res.cloudinary.com/testcloudperfom-shop/image/upload/v1599355574/Capture_d_e%CC%81cran_2020-09-06_a%CC%80_02.13.52_gwg73s.jpg)


##### then copy package name <Strong>org.elliote.findme<Strong>

![Create Project](https://res.cloudinary.com/testcloudperfom-shop/image/upload/v1599356888/Capture_d_e%CC%81cran_2020-09-06_a%CC%80_02.47.39_diulcc.png)

then click next and download <Strong>google-services.json<Strong>

##### Go to folder android/app and replace the existing google-services.json by the new one

### Ios Config

##### Now configure FireBase for Ios click on 

![Create Project](https://res.cloudinary.com/testcloudperfom-shop/image/upload/v1599355596/Capture_d_e%CC%81cran_2020-09-06_a%CC%80_02.13.52_1_dkwqde.jpg)

Do the same thing as android but this time download <Strong> GoogleService-Info.plist </Strong>

##### Go to folder ios replace the existing GoogleService-Info.plist by the new one


[Site]: https://firebase.google.com/