# System Requirements

####  1) Install Node js

You can download lastet version from [here] 
> Used version For Dev [v10.15.2].

####  2) Install yarn

install s [Homebrew]
```
brew install yarn
``` 
- **Other Plateforme:** use Directly [yarn]

####  3) Install React Native
Install React native Cli using 
```
npm install -g react-native-cli
```
> More inromations to configure environement can be found in officale website of [react-native]


### Mac OS only you need to install cocoapods

> More Information can be found here https://cocoapods.org/

## For More information about Environement Setup Refer to 
> More inromations to configure environement can be found in officale website of [react-native]



[here]: https://nodejs.org/en/download/
[v10.15.2]: https://nodejs.org/en/blog/release/v10.15.2/
[react-native]: https://reactnative.dev/docs/environment-setup/
[Homebrew]: https://brew.sh/
[yarn]: https://classic.yarnpkg.com/en/docs/install/#windows-stable/