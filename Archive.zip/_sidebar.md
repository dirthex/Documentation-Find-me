![Xcode config](https://res.cloudinary.com/testcloudperfom-shop/image/upload/v1599698180/logo_Plan_de_travail_1_ygrzms.png)

- **Find ME**

* [Introduction](/)
* [System Requirements](Instalattion.md)
* [Getting started](start.md)
* [Configuration Fireabse](firebase.md)
* [How to change splash screen ?](splash.md)
* [How to Use nfc tag ?](nfc.md)
* [How to Use Qr code ?](qr.md)
* [Universal Linking](linking.md)
* [Mockup api](mockup.md)
* [Credits and attribution](credit.md)

<img src="https://www.e-lliote.com/_next/static/images/logo3-4e84bfc51f0b7e745926e96b7a82456e.webp" width="50%%" >