# Credit And attribution


###### ALL images used for products and stores Are from Freepik To use the same You need to download them

###### Used Images Credits

 - store 1 <a href="https: - www.freepik.com/vectors/logo">Logo vector created by starline - www.freepik.com</a> https: - www.freepik.com/free-vector/pure-natural-organic-label-sticker_9106212.htm

 - store 2 <a href="https: - www.freepik.com/vectors/logo">Logo vector created by freepik - www.freepik.com</a>  https: - www.freepik.com/free-vector/supermarket-logo-template_6982115.htm

 - store 3 <a href="https: - www.freepik.com/vectors/logo">Logo vector created by freepik - www.freepik.com</a>  https: - www.freepik.com/free-vector/creative-colorful-gaming-logo_8561014.htm

 - store 4 <a href="https: - www.freepik.com/vectors/logo">Logo vector created by freepik - www.freepik.com</a>  https: - www.freepik.com/free-vector/detailed-travel-logo-with-plane_9270466.htm

 - product 1 <a href='https: - www.freepik.com/psd/mockup'>Mockup psd created by freepik - www.freepik.com</a>   https: - www.freepik.com/free-psd/delicious-honey-product-table_7822575.htm

 - product 2 <a href='https: - www.freepik.com/vectors/marketing'>Marketing vector created by pikisuperstar - www.freepik.com</a> https: - www.freepik.com/free-vector/realistic-ginseng-ad_8488043.htm

 - product 3 <a href="https: - www.freepik.com/vectors/design">Design vector created by macrovector - www.freepik.com</a> https: - www.freepik.com/free-vector/organic-cosmetics-ingredients-advertising-realistic-composition-with-new-collection-natural-ingredients-descriptions-vector-illustration_7201343.htm

 - product 4 <a href="https: - www.freepik.com/vectors/cartoon">Cartoon vector created by macrovector - www.freepik.com</a> https: - www.freepik.com/free-vector/cartoon-berry-smoothie-sticker_9586029.htm

 - product 5 <a href="https: - www.freepik.com/vectors/flyer">Flyer vector created by freepik - www.freepik.com</a> https: - www.freepik.com/free-vector/detox-organic-smoothie-bar-square-flyer_9261984.htm

 - product 6 <a href="https: - www.freepik.com/vectors/background">Background vector created by vectorpouch - www.freepik.com</a> https: - www.freepik.com/free-vector/cheese-slices-3d-illustration-sliced-emmental-cheddar-edam-cheese-with-holes_2890861.htm

 - product 7 https: - www.freepik.com/premium-vector/gamepad-mockup-vector-illustration-game-joystick_4346158.htm#page=1&query=Joystick&position=5

 - product 8 https: - www.freepik.com/free-vector/consoles-set-flat-design_943299.htm#page=1&query=Console&position=27

 - product 9 https: - www.freepik.com/premium-vector/man-wearing-virtual-reality-headset-from-splash-watercolor-hand-drawn-sketch_9378527.htm#page=1&query=vr%20headset&position=8

 - product 10 <a href="https: - www.freepik.com/vectors/background">Background vector created by freepik - www.freepik.com</a>  https: - www.freepik.com/free-vector/flat-travel-background_3715255.htm


 - ads 1 <a href="https: - www.freepik.com/vectors/banner">Banner vector created by BiZkettE1 - www.freepik.com</a> https: - www.freepik.com/free-vector/special-offer-big-sale-background_9394689.htm#position=1

 - ads 2 <a href="https: - www.freepik.com/vectors/banner">Banner vector created by upklyak - www.freepik.com</a> https: - www.freepik.com/free-vector/thermal-water-cosmetic-bottle-with-spf-ad-banner_9395734.htm#position=0

 - ads 3 <a href="https: - www.freepik.com/vectors/logo">Logo vector created by katemangostar - www.freepik.com</a> https: - www.freepik.com/free-vector/best-season-sale-thirty-percent-off-banner-template-with-dandelion_2538703.htm

 - ads 4 <a href="https: - www.freepik.com/vectors/background">Background vector created by frimufilms - www.freepik.com</a> https: - www.freepik.com/free-vector/herbal-set-cosmetic-with-wooden-cap-thermal-water-serum-cream-lotion-body-mask-spray-milk-tonic-place-text-product-placement_9640994.htm



###### Used Aimation asset Credits

 - lottie diamond animation credit to @danielseiler/LottieFiles
you can find animation here https://assets4.lottiefiles.com/datafiles/yxuKqdi8TvAkNfF/data.json
> author profile : https://lottiefiles.com/danielseiler


 - lottie loader animation credit to @kshivang/LottieFiles
you can find animation here https://assets9.lottiefiles.com/packages/lf20_6bn9xZ.json
> author profile : https://lottiefiles.com/kshivang